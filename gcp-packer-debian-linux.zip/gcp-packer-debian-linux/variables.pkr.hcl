variable "build_number" {
  type    = string
  default = "0"
}

variable "pwd" {
  type    = string
  default = env("PWD")
}

# GCP builder variables
variable "gcp_project_id" {
  type    = string
  default = env("GCP_PROJECT_ID")
}

variable "gcp_credentials_file" {
  type    = string
  default = env("GCP_CREDENTIALS_FILE")
}

variable "gcp_zone" {
  type    = string
  default = "us-central1-a"
}

variable "gcs_bucket" {
  type    = string
  default = env("GCS_BUCKET")
}

variable "ssh_public_key" {
  type    = string
  default = env("PACKER_SSH_PUBLIC_KEY")
}

variable "post" {
  type = list(object({
    name   = string
    target = string
    groups = list(string)
  }))
  default = []
}
