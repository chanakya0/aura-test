# TODO list for Quem packer project

## Jenkins Pipeline
- [DONE] Image Vsphere cleanup, remove any image templates older than five days.
- [WIP] Add integration test via molecule to pipeline.
- Redhat License cleanup against satellite.
- Incorporate Git release workflow.

## Molecule Automated Testing
- Local testing with Qemu driver.
- Remote testing VMWare trap instance creation failures.
- Document test workflow for build and runtime.

## Ansible Runtime
- Establish pattern for playbook naming and inclusion.
- Standardize subclassification for Ansible group.

## Ansible Build
- Standardize OS group names between run and build time.
- [DONE]First pass and clean up for builds

## Ansible General
- Code cleanup.

## Tech Debt
- Remove sssd from seed images, Probably not an image if we fix the follow issue on the list.
- Use oldest content view available for seed image creation to avoid mismatch yum packages on layered builds.
- [DONE] Move oscap reports out of `ansible_project_cloud_infra/playbooks/artifacts/` and into `packer_cache/artifacts`.