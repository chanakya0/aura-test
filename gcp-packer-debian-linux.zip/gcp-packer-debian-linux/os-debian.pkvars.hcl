# GCP builder uses the cloud image directly — no ISO or boot_command needed.
# Source image: debian12-hardened-20260626-22
# Source project: odev-eiaas-dev-vmi-archv-b9ba

post = [
  {
    name   = "debian12"
    target = "local_artifact"
    groups = ["debian12", "debian", "local_artifact"]
  }
]
