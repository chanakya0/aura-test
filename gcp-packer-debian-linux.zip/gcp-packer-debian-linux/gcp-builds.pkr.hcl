packer {
  required_version = ">= 1.11.0"
  required_plugins {
    googlecompute = {
      version = ">= 1.1.0"
      source  = "github.com/hashicorp/googlecompute"
    }
    ansible = {
      version = ">= 1.1.2"
      source  = "github.com/hashicorp/ansible"
    }
  }
}

locals {
  build_time     = "${formatdate("YYYYMMDD", timestamp())}.${var.build_number}"
  gcp_image_name = "debian12-hardened-${formatdate("YYYYMMDD", timestamp())}-${var.build_number}"
}

build {
  name = "post"

  dynamic "source" {
    for_each = { for idx, src in var.post : "${src.name}@${idx}" => src }
    iterator = it
    labels   = ["googlecompute.debian12"]
    content {
      name = "${it.value.name}@${it.value.target}"
    }
  }

  provisioner "ansible" {
    user          = "debian"
    playbook_file = "ansible/site.yml"
    timeout       = "2h"
    use_proxy     = false

    roles_path       = "packer_cache/ansible/roles/${source.name}"
    collections_path = "packer_cache/ansible/collections/${source.name}"

    galaxy_force_install = true
    galaxy_command       = "bin/ansible-galaxy.sh"
    galaxy_file          = fileexists("ansible/requirements.yml") ? "ansible/requirements.yml" : null

    ansible_env_vars = [
      "ANSIBLE_ROLES_PATH=${var.pwd}/packer_cache/ansible/roles/${source.name}",
      "ANSIBLE_COLLECTIONS_PATH=~/.ansible/collections:/usr/share/ansible/collections:${var.pwd}/packer_cache/ansible/collections/${source.name}"
    ]

    groups = flatten([
      [
        split("@", source.name)[0],
        split("@", source.name)[1],
        source.type,
      ],
      {
        for i in var.post :
        "${i.name}@${i.target}" => lookup(i, "groups", [])
      }[source.name]
    ])

    extra_arguments = [
      "--ssh-extra-args",
      "-o IdentitiesOnly=yes -o IdentityFile=''",
      "--ssh-extra-args",
      "-F /dev/null",
      "--extra-vars",
      "openscap_report_name=${source.name}",
      "--extra-vars",
      "min_ansible_version=2.13.0",
      "--become",
      "--become-user=root"
    ]
  }

  # Run OpenSCAP score check
  post-processor "shell-local" {
    command = "bin/openscap.sh -f ansible/artifacts/${source.name}_image_scan_results.xml"
  }

  # Export GCP image as RAW (disk.raw inside tar.gz) to GCS.
  # RAW is the native GCP import/export format — no conversion overhead.
  # The exported tar.gz can be re-imported into any GCP project directly.
  post-processor "shell-local" {
    environment_vars = [
      "BUILD_TIME=${local.build_time}",
      "GCP_PROJECT_ID=${var.gcp_project_id}",
      "GCS_BUCKET=${var.gcs_bucket}"
    ]
    command = <<-CMD
      bin/export-from-gcp.sh \
        "${local.gcp_image_name}" \
        "post/${source.name}.tar.gz"
    CMD
  }
}
