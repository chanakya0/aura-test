source "googlecompute" "debian12" {
  project_id   = var.gcp_project_id
  credentials_file = var.gcp_credentials_file

  # Cloud image from the hardened Debian 12 build in the source project
  source_image            = "debian12-hardened-20260626-22"
  source_image_project_id = ["odev-eiaas-dev-vmi-archv-b9ba"]

  zone         = var.gcp_zone
  machine_type = "n2-standard-4"
  disk_size    = 75
  disk_type    = "pd-ssd"

  network    = "projects/neustar-lz/global/networks/neustar-vpc-lz1"
  subnetwork = "projects/neustar-lz/regions/us-central1/subnetworks/neustar-shared-infra-usc1-dev-subnet-51d7"

  ssh_pty      = true
  ssh_username = "debian"
  ssh_timeout  = "3h"

  image_name        = "debian12-hardened-${formatdate("YYYYMMDD", timestamp())}-${var.build_number}"
  image_family      = "debian12-hardened"
  image_description = "CIS hardened Debian 12 - build ${var.build_number}"

  # No public IP — VM reaches Artifactory via internal network
  omit_external_ip = true
  use_internal_ip  = true

  metadata = {
    ssh-keys       = "debian:${var.ssh_public_key}"
    enable-oslogin = "FALSE"
  }

  tags = ["packer-build"]

  skip_create_image = false
}
