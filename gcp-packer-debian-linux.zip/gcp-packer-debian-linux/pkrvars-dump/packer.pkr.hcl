# This HCL file is used for converting variables in json to hcl
# It does not provide and adddtional functionality and is not part
# of the larger build project in this repo.

variable "_json_to_hcl_dump" {}
source "null" "json_to_hcl_dump" {communicator = "none"}
build {sources = ["sources.null._json_to_hcl_dump"]}
