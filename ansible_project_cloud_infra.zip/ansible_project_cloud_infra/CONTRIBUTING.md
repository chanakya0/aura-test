# How to contribute
I'm really glad you're reading this, because we love contributors :)

Here are some important resources:

  * TODO: Add resource here
  * TODO: Add resource here

## Testing
Please write integration tests for new code you create in the [integration testing repo](https://git.transunion.com/projects/CIP/repos/cloud-ami-integration/browse).

Changes should be tested by running the respective builds with the cloud-image-linux-aws pipeline. This pipeline will test the following:
  * Image builds successfully
  * Instance creates successfully from image built
  * Instance bootstraps successfully from instance created
  * Instance passes integration tests
  * Instance passes OpenSCAP scan

**Note:** Please manually validate that the OS hardening posture hasn't regressed by going into the succesful build and reviewing the OpenSCAP results. The score should be 100%.

### Testing your changes on develop branch
  1. Navigate to the main branch for the [cloud-image-linux-aws](https://jcm-5.transunion.com/job/Cloud-IAC/job/Cloud%20Infrastructure%20Engineering%20Automation/job/Cloud%20Image%20Pipeline/job/cloud-image-linux-aws/) pipeline
  2. Choose `Build with Parameters` from the left navigation pane
  3. For BuildConfig, enter the appropriate value based on the following table

| Build to test   | BuildConfig           |
| --------------- | --------------------- |
| All build types | ifa/devel.json        |
| rhel79 only     | ifa/devel_rhel79.json |
| rhel86 only     | ifa/devel_rhel86.json |

## Submitting changes
Changes should start on a feature branch. When your changes are ready, submit a pull request to merge to the develop branch. Once merged to the develop branch, please test your changes using the above testing procedures. Once your changes have been tested and are ready to be promoted, submit a pull request to merge to the main branch.

Always write a clear log message for your commits. We prefer you use [Conventional commits](https://www.conventionalcommits.org/en/v1.0.0/).

## Coding conventions
Start reading our code and you'll get the hang of it. Here are some guidelines:

  * TODO: Add guideline here
  * TODO: Add guideline here
