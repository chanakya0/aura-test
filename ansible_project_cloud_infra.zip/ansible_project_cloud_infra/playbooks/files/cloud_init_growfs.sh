#!/usr/bin/env bash
set -e
RESIZE_THRESHOLD="2147483648"
DIGIT_REGEX="[[:digit:]]+"
DEVICE_REGEX="^/dev"
ROOTVG_NAME=$(pvs --noheadings | grep rootvg | awk '{print$1}')
ROOTVG_SIZE=$(lsblk -b -n -l -p -o NAME,SIZE,TYPE | grep "$ROOTVG_NAME" | awk '{print$2}')
ROOTVG_PART="${ROOTVG_NAME: -1}"
DRIVE_NAME=$(lsblk -b -n -l -p -o NAME,SIZE,TYPE | grep disk | awk '{print$1}')
DRIVE_SIZE=$(lsblk -b -n -l -p -o NAME,SIZE,TYPE | grep disk | awk '{print$2}')
SIZE_DIFF=$(( DRIVE_SIZE - ROOTVG_SIZE ))


if [[ ! "$ROOTVG_NAME" =~ $DEVICE_REGEX ]] ; then
  echo "Recieved unexpected device format: '${ROOTVG}'" >&2
  exit 1
fi


if [[ ! -b "$ROOTVG_NAME" ]]  ; then
  echo "File path found is not block device: '${ROOTVG}'">&2
  exit 1
fi

if [[ ! -b "$DRIVE_NAME" ]]  ; then
  echo "File path found is not block device: '${DRIVE_NAME}'" >&2
  exit 1
fi

for item in ROOTVG_SIZE ROOTVG_PART DRIVE_SIZE RESIZE_THRESHOLD SIZE_DIFF ; do
  if [[ ! "${!item}" =~ $DIGIT_REGEX ]]  ; then
    echo "Non-digit found in results for '${item}: ${!item}'" >&2
    exit 1
  fi
done

if [[ "$SIZE_DIFF" -gt "$RESIZE_THRESHOLD" ]] ; then
  growpart "$DRIVE_NAME" "$ROOTVG_PART"
  pvresize "$ROOTVG_NAME"
fi

exit 0