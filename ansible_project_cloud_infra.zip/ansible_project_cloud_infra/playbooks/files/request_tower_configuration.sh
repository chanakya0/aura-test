#!/bin/bash

set -xeo pipefail

exec 1> >(logger -s -t $(basename $0)) 2>&1
trap cleanup EXIT

fatal() {
  if [ -n "${2}" ]; then
    printf '{"error": "%s"}' "$2"
  fi
  exit "${1}"
}

function cleanup() {
  local exitcode=$?
  rm -f "$RUNTIME_TMP_TAGS_FILE"
  exit "$exitcode"
}

function fetch_gcp_labels() {
  local output_file="$1"
  if [[ -z "$output_file" ]] ; then
    echo "Required params for not passed to metadata labels!" >&2
    return 1
  fi

  if [[ -z "$GCP_INSTANCE_ZONE" ]] ; then
    echo "Required global GCP_INSTANCE_ZONE not set." >&2
    return 1
  fi

  local gcloud_result
  gcloud_result=$(gcloud compute instances list --filter="name=$(hostname)" --format='json' | jq '.[].labels') || \
    echo "Unable to fetch labels from gcp" >&2
  if [[ "$gcloud_result" == "null" ]] || [[ -z "$gcloud_result" ]] ; then
    gcloud_result='{"error":"Unable to fetch tags from gcp for host."}'
  fi
  echo '{"runtime_instance_tags":' > "$output_file"
  echo "$gcloud_result" >> "$output_file"
  echo '}' >> "$output_file"
  return 0
}


function fetch_gcp_metadata() {
  local output_file="$1"
  if [[ -z "$output_file" ]] ; then
    echo "Required params for not passed to write labels!" >&2
    return 1
  fi

  if [[ -z "${GCP_META_KEYS[0]}" ]] ; then
    echo "Required global GCP_META_KEYS not set." >&2
    return 1
  fi
  echo -e '{"runtime_instance_tags": {' > "$output_file"
  local indexes=("${!GCP_META_KEYS[@]}")
  local last="${indexes[-1]}"

  for idx in "${indexes[@]}" ; do
    local key=${GCP_META_KEYS[$idx]}
    local tmp
    local value="__NULL__"
    tmp=$(curl $GCP_CURL_OPTS -X GET "${GCP_META_URL}/instance/attributes/$key" -H "$GCP_CURL_HEAD") && {
      value="$tmp"
    }
    printf '"%s": "%s"' "$key" "${value}" >> "$output_file"
    if [[ "$idx" -ne "$last" ]] ; then
      echo -e "," >> "$output_file"
    fi
  done
  echo '}}' >> "$output_file"
}


function skip_bootstrap() {
  local skip_code=125
  local extra_vars="$1"

  if [[ -z "$extra_vars" ]] ; then
    echo "Required params to query extra_vars" >&2
    return 1
  fi

  local query_mds
  local key="skip_bootstrap"
  query_mds=$(curl $GCP_CURL_OPTS -X GET "${GCP_META_URL}/instance/attributes/$key" -H "$GCP_CURL_HEAD") || true

  if [[ "${query_mds:-false}" == "true" ]] ; then
    echo "Bootstrap being skipped based on metadata !" >&2
    rm "$BOOTSTRAP_STATUS_FILE"
    exit $skip_code
  fi

  local tags_length
  tags_length=$(jq -r '.runtime_instance_tags | with_entries(select(.value != "__NULL__")) | length' "$extra_vars")
  if [[ "$tags_length" -eq 0 ]] ; then
    echo "Zero length found for object !" >&2
    rm "$BOOTSTRAP_STATUS_FILE"
    exit $skip_code
  fi

  return 0
}


function write_bootstrap_status() {
  local bootstrap_status="$1"
  if [[ -z "$bootstrap_status" ]] ; then
    echo "Required param to bootstrap_status not passed." >&2
    return 1
  fi

  if [[ -z "$GCP_INSTANCE_ZONE" ]] ; then
    echo "Required global GCP_INSTANCE_ZONE not set." >&2
    return 1
  fi

  gcloud compute instances add-labels "$GCP_INSTANCE_NAME" --zone "$GCP_INSTANCE_ZONE" --labels bootstrap_status="$bootstrap_status"  || \
    echo "Unable to write bootstrap status continuing..." >&2
  return 0
}

function get_instance_name() {
  GCP_INSTANCE_NAME=$(curl $GCP_CURL_OPTS -X GET "${GCP_META_URL}/instance/name" -H "$GCP_CURL_HEAD") \
    || fatal 1 "Unable to get instance name from gcp metadata."
  readonly GCP_INSTANCE_NAME
  return 0
}

function get_instance_zone() {
  GCP_INSTANCE_ZONE=$(curl $GCP_CURL_OPTS -X GET "${GCP_META_URL}/instance/zone" -H "$GCP_CURL_HEAD") \
    || fatal 1 "Unable to get instance zone from gcp metadata."
  readonly GCP_INSTANCE_ZONE
  return 0
}

function sanitize_extra_vars() {
  local extra_vars_file="${1:-}"
  if [[ -z "$extra_vars_file" ]] ; then
    return 1
  fi
  query='.runtime_instance_tags |= with_entries(select(.value != "__NULL__"))'
  jq -c "$query" < "$extra_vars_file" || return 1
  return 0
}

function add_classification() {
  local vars_file="${1:-}"
  local gcp_zone="${2:-}"

  if [[ -z "$vars_file" ]] ; then
    return 1
  fi

  if [[ -z "$gcp_zone" ]] ; then
    return 1
  fi
  local gcp_base=$(basename "$gcp_zone")
  local gcp_region="${gcp_base%-*}"
  local gcp_clean="${gcp_region/-/}"
  local tu_domain=$(jq -r '.runtime_instance_tags.domain' "$vars_file") || {
    echo "Unable to get domain from extra_vars." >&2
    return 1
  }
  local class="gcp_${gcp_clean}_${tu_domain}"

  tmp_file=$(mktemp) || {
    echo "Unable to create temp file." >&2
    return 1
  }
  jq -c '.runtime_instance_tags.classification="'$class'"' "$vars_file" > "$tmp_file" || {
    echo "Unable to append classification to extra_vars." >&2
    return 1
  }
  mv "$tmp_file" "$vars_file" || {
    echo "Unable to move tmp_file into place." >&2
    return 1
  }
  return 0
}


mapfile  -t GCP_META_KEYS <<'EOF'
environment
domain
location
app_user_group
app_admin_group
app_prc_group
app_svc_group
EOF

readonly GCP_META_URL="http://metadata.google.internal/computeMetadata/v1"
readonly GCP_CURL_OPTS="--max-time 30 --retry 3 --retry-delay 2 --retry-max-time 15 -Ssf"
readonly GCP_CURL_HEAD="Metadata-Flavor: Google"
readonly OS_BS_ENVVARS="/etc/bootstrap-runtime/env-vars"
readonly IPREGEX="^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$"


echo "Starting bootstrap-runtime service..."

# source bootstrap-runtime env-vars when manually testing
if [[ -n "$IS_TEST" ]] ; then
  TEMPFILE=$(mktemp)
  sed 's/^/export /' "$OS_BS_ENVVARS"  > "$TEMPFILE"
  source "$TEMPFILE"
  rm -r "$TEMPFILE"
fi

cat <<'EOF' |
CONTROLLER_HOST
CONTROLLER_OAUTH_TOKEN
RUNTIME_JOBNAME
RUNTIME_SCM_BRANCH
RUNTIME_TMP_TAGS_FILE
BOOTSTRAP_STATUS_FILE
VIRTUAL_ENV
EOF
while read -r i ; do
  if [[ -z "${!i}" ]] ; then
    fatal 1 "Required env-vars not set for $i"
  else
    readonly "$i"
  fi
done

get_instance_name
get_instance_zone

source "${VIRTUAL_ENV}/bin/activate"
which awx || fatal 1 "Unable to find awx binary in path."

MAX_WAIT="5 minute"
TIME_OUT=$(date -ud "$MAX_WAIT" +%s)
while [[  $(date -u +%s) -le $TIME_OUT ]] ; do
  INSTANCE_IP="$(hostname -i)"
  if [[ "$INSTANCE_IP" =~ $IPREGEX ]] ; then
    echo "-1" > "$BOOTSTRAP_STATUS_FILE"
    break
  fi
  sleep 1
done

if [[ ! -f $BOOTSTRAP_STATUS_FILE ]] ; then
  echo "-1" > "$BOOTSTRAP_STATUS_FILE"
  fatal 1 "Unable to determine ip before timeout."
fi

fetch_gcp_metadata "$RUNTIME_TMP_TAGS_FILE" || {
  fatal 1 "Unable to fetch metadata !"
}

if [[ ! -f "$RUNTIME_TMP_TAGS_FILE" ]]  ; then
  fatal 1 "Unable to stat tags file: $RUNTIME_TMP_TAGS_FILE"
fi

skip_bootstrap "$RUNTIME_TMP_TAGS_FILE"

sanitize_extra_vars "$RUNTIME_TMP_TAGS_FILE" || \
  fatal 1 "Unable to set extra-vars from file."

add_classification "$RUNTIME_TMP_TAGS_FILE" "$GCP_INSTANCE_ZONE" || {
  echo "Unable to add classification to extra_vars." >&2
}

awx job_templates launch "$RUNTIME_JOBNAME" \
  --wait --scm_branch "$RUNTIME_SCM_BRANCH" \
  --limit "localhost,$INSTANCE_IP" \
  --extra_var "@$RUNTIME_TMP_TAGS_FILE" || {
  fatal 1 "Job run did NOT return successfully"
  }

echo '{"bootstrap": "0"}'
exit 0
