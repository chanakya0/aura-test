# GCP builder uses imported image directly — no ISO or boot_command needed.
# prep phase is removed; GCP boots directly from the imported custom image.

post = [
  {
    name   = "debian12"
    target = "local_artifact"
    groups = ["debian12", "debian", "local_artifact"]
  }
]
