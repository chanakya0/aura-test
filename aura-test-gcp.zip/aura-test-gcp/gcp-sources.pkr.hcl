source "googlecompute" "enterprise_linux" {
  project_id              = var.gcp_project_id
  credentials_file        = var.gcp_credentials_file

  # Uses the imported custom image as base
  source_image            = var.gcp_source_image
  source_image_project_id = [var.gcp_project_id]

  zone                    = var.gcp_zone
  machine_type            = "n2-standard-4"   # 4 vCPU, 16GB — matches QEMU 4cpu/8GB
  disk_size               = 75                # matches var.size
  disk_type               = "pd-ssd"

  ssh_username            = "root"
  ssh_private_key_file    = "${var.config_folder}/.ssh/id_rsa"
  ssh_timeout             = "3h"

  # GCP image output name
  image_name              = "debian12-hardened-{{timestamp}}-${var.build_number}"
  image_family            = "debian12-hardened"
  image_description       = "CIS hardened Debian 12 - build ${var.build_number}"

  # No public IP needed if VM has internal access to Artifactory
  omit_external_ip        = false   # set true if using Cloud Interconnect/VPN
  use_internal_ip         = false

  # Startup metadata
  metadata = {
    enable-oslogin = "FALSE"
  }

  tags = ["packer-build"]

  skip_create_image = false
}
