packer {
  required_version = ">= 1.11.0"
  required_plugins {
    googlecompute = {
      version = ">= 1.1.0"
      source  = "github.com/hashicorp/googlecompute"
    }
    ansible = {
      version = ">= 1.1.2"
      source  = "github.com/hashicorp/ansible"
    }
  }
}

locals {
  build_time     = "${formatdate("YYYYMMDD", timestamp())}.${var.build_number}"
  gcp_image_name = "debian12-hardened-${formatdate("YYYYMMDD", timestamp())}-${var.build_number}"
}

build {
  name = "post"

  dynamic "source" {
    for_each = { for idx, src in var.post : "${src.name}@${idx}" => src }
    iterator = it
    labels   = ["googlecompute.enterprise_linux"]
    content {
      name = "${it.value.name}@${it.value.target}"
    }
  }

  provisioner "ansible" {
    user                 = "root"
    playbook_file        = "ansible/site.yml"
    timeout              = "2h"
    roles_path           = "packer_cache/ansible/roles/${source.name}"
    collections_path     = "packer_cache/ansible/collections/${source.name}"
    galaxy_force_install = true
    galaxy_command       = "bin/ansible-galaxy.sh"
    galaxy_file          = fileexists("ansible/requirements.yml") ? "ansible/requirements.yml" : null

    ansible_env_vars = [
      "ANSIBLE_ROLES_PATH=${var.pwd}/packer_cache/ansible/roles/${source.name}",
      "ANSIBLE_COLLECTIONS_PATHS=~/.ansible/collections:/usr/share/ansible/collections:${var.pwd}/packer_cache/ansible/collections/${source.name}",
      "ANSIBLE_KEEP_REMOTE_FILES=1",
      "ANSIBLE_SSH_RETRIES=5",
      "ANSIBLE_TIMEOUT=60",
      "ANSIBLE_SSH_ARGS=-o ControlMaster=auto -o ControlPersist=4h -o ControlPath=/tmp/ansible-ssh-%h-%p-%r -o ServerAliveInterval=30 -o ServerAliveCountMax=10 -o TCPKeepAlive=yes"
    ]

    groups = flatten([[
      split("@", source.name)[0],
      split("@", source.name)[1],
      source.type,
      ],
      { for i in var.post :
      "${i.name}@${i.target}" => lookup(i, "groups", []) }[source.name]
    ])

    extra_arguments = [
      "--extra-vars",
      "ansible_ssh_private_key_file=${var.config_folder}/.ssh/id_rsa",
      "--extra-vars",
      "openscap_report_name=${source.name}",
      "--extra-vars",
      "min_ansible_version=2.13.0",
      "--scp-extra-args", "'-O'",
      "--ssh-extra-args", "-o ServerAliveInterval=30 -o ServerAliveCountMax=10"
    ]
  }

  # Run OpenSCAP score check
  post-processor "shell-local" {
    command = "bin/openscap.sh -f ansible/artifacts/${source.name}_image_scan_results.xml"
  }

  # Export GCP image back to qcow2
  post-processor "shell-local" {
    environment_vars = [
      "BUILD_TIME=${local.build_time}",
      "GCP_PROJECT_ID=${var.gcp_project_id}",
      "GCS_BUCKET=${var.gcs_bucket}"
    ]
    command = <<-CMD
      bin/export-from-gcp.sh \
        "${local.gcp_image_name}-${source.name}" \
        "post/${source.name}.qcow2"
    CMD
  }

  # Upload qcow2 to Artifactory
  post-processor "shell-local" {
    name = "jfrog_import"
    only = [
      for p in var.post :
      "googlecompute.${p.name}@${p.target}" if contains(values(p), "local_artifact")
    ]
    command = <<-CMD
      bin/validate-os.sh post/${source.name}.qcow2 || exit 1
      ${var.artifact.binary} rt upload 'post/${source.name}.qcow2' \
        '${var.artifact.target}/${split("@", source.name)[0]}-x86_64-${local.build_time}.qcow2' \
        --url '${var.artifact.url}' \
        --user "$JFROG_USER" \
        --password "$JFROG_PASSWORD" \
        --fail-no-op=true \
        --build-name '${var.artifact.name}' \
        --build-number='${var.build_number}' \
        --target-props 'os=${split("@", source.name)[0]}' && \
        touch packer_cache/${source.name}.jfrog
    CMD
  }
}
