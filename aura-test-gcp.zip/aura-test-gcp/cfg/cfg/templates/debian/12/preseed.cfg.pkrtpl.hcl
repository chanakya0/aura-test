# Debian 12 (Trixie) Preseed Configuration
# Used by Packer QEMU builder for automated unattended installation.

# Locale and keyboard
d-i debian-installer/locale string en_US.UTF-8
d-i keyboard-configuration/xkb-keymap select us

# Network - DHCP, no IPv6
d-i netcfg/choose_interface select auto
d-i netcfg/get_hostname string debian12
d-i netcfg/get_domain string localdomain
d-i netcfg/wireless_wep string

# Use the ISO as the only package source - no external mirror
d-i apt-setup/use_mirror boolean false
d-i apt-setup/no_mirror boolean true
d-i apt-setup/cdrom/set-first boolean true
d-i apt-setup/cdrom/set-next boolean false
d-i apt-setup/cdrom/set-failed boolean false
d-i apt-setup/services-select multiselect
d-i apt-setup/security_host string

# Mirror settings (suppresses prompts; mirror is not used)
d-i mirror/country string manual
d-i mirror/http/hostname string 127.0.0.1
d-i mirror/http/directory string /debian
d-i mirror/http/proxy string

# Clock and timezone
d-i clock-setup/utc boolean true
d-i time/zone string America/Chicago
d-i clock-setup/ntp boolean true
d-i clock-setup/ntp-server string ${split(",", ntp_servers)[0]}
# SSH public key is hardcoded below from debian-baseimage/id_rsa.pub

# Root account - temporary password for debugging, SSH key also injected
d-i passwd/root-login boolean true
d-i passwd/root-password password packer
d-i passwd/root-password-again password packer
d-i passwd/make-user boolean false

# Disk partitioning - LVM, wipe entire disk
d-i partman-auto/disk string /dev/vda
d-i partman-auto/method string lvm
d-i partman-lvm/device_remove_lvm boolean true
d-i partman-md/device_remove_md boolean true
d-i partman-lvm/confirm boolean true
d-i partman-lvm/confirm_nooverwrite boolean true
d-i partman-auto/choose_recipe select custom
d-i partman-auto-lvm/new_vg_name string rootvg
d-i partman-auto-lvm/guided_size string max

d-i partman-auto/expert_recipe string         \
  custom ::                                   \
    1 1 1 free                                \
      $bios_boot{ }                           \
      method{ biosgrub }                      \
    .                                         \
    1024 1024 1024 xfs                        \
      $primary{ }                             \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /boot }                     \
      label{ BOOT }                           \
    .                                         \
    1 1 -1 lvm                                \
      $primary{ }                             \
      method{ lvm }                           \
      vg_name{ rootvg }                       \
    .                                         \
    10240 10240 10240 xfs                     \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ root }                         \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ / }                         \
      label{ ROOT }                           \
    .                                         \
    6144 6144 6144 xfs                        \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ var }                          \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /var }                      \
      options/nosuid{ nosuid }                \
    .                                         \
    2048 2048 2048 xfs                        \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ var_log }                      \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /var/log }                  \
      options/nodev{ nodev }                  \
      options/noexec{ noexec }                \
      options/nosuid{ nosuid }                \
    .                                         \
    10240 10240 10240 xfs                     \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ var_log_audit }                \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /var/log/audit }            \
      options/nodev{ nodev }                  \
      options/noexec{ noexec }                \
      options/nosuid{ nosuid }                \
    .                                         \
    2048 2048 2048 xfs                        \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ tmp }                          \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /tmp }                      \
      options/nodev{ nodev }                  \
      options/noexec{ noexec }                \
      options/nosuid{ nosuid }                \
    .                                         \
    5120 5120 5120 xfs                        \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ home }                         \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /home }                     \
      options/nodev{ nodev }                  \
      options/nosuid{ nosuid }                \
    .                                         \
    10240 10240 10240 xfs                     \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ opt }                          \
      method{ format } format{ }              \
      use_filesystem{ } filesystem{ xfs }     \
      mountpoint{ /opt }                      \
    .                                         \
    2048 2048 2048 linux-swap                 \
      $lvmok{ } in_vg{ rootvg }              \
      lv_name{ swap }                         \
      method{ swap } format{ }               \
    .

d-i partman-partitioning/confirm_write_new_label boolean true
d-i partman/choose_partition select finish
d-i partman/confirm boolean true
d-i partman/confirm_nooverwrite boolean true
d-i partman-md/confirm boolean true

# Base package selection
tasksel tasksel/first multiselect standard
d-i pkgsel/include string \
  openssh-server \
  sudo \
  curl \
  wget \
  vim \
  git \
  lvm2 \
  chrony \
  rsyslog \
  aide \
  auditd \
  apparmor \
  apparmor-utils \
  libpam-pwquality \
  python3 \
  python3-apt \
  net-tools \
  bind9-utils \
  sysstat \
  lsof \
  iotop \
  strace \
  gdisk \
  tar \
  qemu-guest-agent

d-i pkgsel/upgrade select none
d-i pkgsel/update-policy select none

# Bootloader
d-i grub-installer/only_debian boolean true
d-i grub-installer/bootdev string /dev/vda

# Disable popularity contest
popularity-contest popularity-contest/participate boolean false

# Post-install script
d-i preseed/late_command string \
  in-target mkdir -p /root/.ssh ; \
  in-target chmod 700 /root/.ssh ; \
  echo "c3NoLXJzYSBBQUFBQjNOemFDMXljMkVBQUFBREFRQUJBQUFDQVFEWkxCVk1EN2ttQ0drVk9ORFJRbVdhUDc2QnAranRNblRib3AyMEpFaGVSYUQreHV4U1hoZDNxS3FudTMxVHpyRmZrVnpFMk12V29VUzRxV0JWaElLOTRqeDBMSGNYZHpMb1JGUGxUcVhhOW5JWUw1bmFsVHp0Q1ZsOFd0MHdQZ1dBdGhIZlRuMzlPUTFlTFhqYjRZZGx3cEdkSVBnbTRnV2xwdDZLbTlDV09KSU1NSDM3ZHNFRUlNSGJ0Z2dBV0ZoY0tKN2pHeGQwN01JY2hjK1NGRXl0TkJwS2MycWtUYnR0cHNhRVJnVTJPOHdBd2lsa2EvV0plSURVU1QvcWhEeEVLR1JnN0dnN2RmbU9nS0sxMkJoRlh4QWJialZaQ0I3UkdVbnREdjlPUnk1a0kvWFVqeGhXMUY1RUpzQ09Dbk45TXVpWHBiMUhPeTgzVGR1dlQ2R05RcHI4OU9CdTNPS2JhSmJvLzlnazNxSjE1UDVVN29ReGVCanpGeFFPTUdiUmxpaDlMUlROMVdYQ0l1Ly8yR205cVNQS1J3MGkrN2huWVgxbWRXTndXN0lPVWJTKzFlWlVwT1BWbUNqNEFRWjFKc3VXM3p6NjNOeWNLdFdlbFlXVkpPUHpiMndrd0M5cUp6Q2h6cjRFNVYzVEhhc3o2UitYQ1RpS1lrMGdvV0dNck9naXlpNkNSUmxZTWNZOStiZmF5K1ZIUkMrYU1IWi8xM2VVSVNsMEJRUURQQzNsSkZqemJYN0crQWg1ekpENlZFSzZNTEIrd1JYQmFzZFAwVjRKQ3FNUnZIUDJPcWdLSmRRR1B1dk92RE4rYmM3RGNFMUh0ZU1xNGhPZXUwV0IwbXhLVTdUMitmcEhoSXhmSlNqOWt1YUpHKzhxVkpRUkoyYytwUU81dXc9PSB0Y2hhbmFrQE1DSElHVzA0NVQwUQo=" | base64 -d > /target/root/.ssh/authorized_keys ; \
  in-target chmod 400 /root/.ssh/authorized_keys ; \
  sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /target/etc/ssh/sshd_config ; \
  sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication yes/' /target/etc/ssh/sshd_config ; \
  grep -q '^PermitRootLogin' /target/etc/ssh/sshd_config || echo "PermitRootLogin yes" >> /target/etc/ssh/sshd_config ; \
  grep -q '^PasswordAuthentication' /target/etc/ssh/sshd_config || echo "PasswordAuthentication yes" >> /target/etc/ssh/sshd_config ; \
  mkdir -p /target/etc/ssh/sshd_config.d ; \
  echo "PermitRootLogin yes" > /target/etc/ssh/sshd_config.d/99-packer.conf ; \
  echo "PasswordAuthentication yes" >> /target/etc/ssh/sshd_config.d/99-packer.conf ; \
  echo "/tmp /var/tmp none bind,nodev,nosuid,noexec 0 0" >> /target/etc/fstab ; \
  echo "tmpfs /dev/shm tmpfs defaults,size=128M,noexec,nodev,nosuid 0 0" >> /target/etc/fstab

# Finish
d-i finish-install/reboot_in_progress note
