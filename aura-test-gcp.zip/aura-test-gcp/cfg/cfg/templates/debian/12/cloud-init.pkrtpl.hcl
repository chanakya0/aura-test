#cloud-config
users:
  - name: root
    lock_passwd: false
    ssh_authorized_keys:
      - ${public_key}

ssh_pwauth: false

chpasswd:
  expire: false

disable_root: false

runcmd:
  - sed -i 's/^#\?PermitRootLogin.*/PermitRootLogin yes/' /etc/ssh/sshd_config
  - sed -i 's/^#\?PasswordAuthentication.*/PasswordAuthentication no/' /etc/ssh/sshd_config
  - systemctl restart sshd
