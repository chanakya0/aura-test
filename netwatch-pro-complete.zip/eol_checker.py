"""
NetWatch Pro — EOL/EOS Detection Engine
Extracts software/firmware versions from discovered devices, checks against
multiple authoritative data sources, and generates risk-scored lifecycle alerts.

Data sources:
  - endoflife.date API (300+ products, free, no key)
  - CISA KEV catalog (known exploited vulnerabilities)
  - NVD CVE API v2 (NIST, optional API key for higher rate limit)
  - OSV.dev (open-source library advisories)
  - Local vendor override table
"""

import json
import logging
import re
import threading
import time
from datetime import datetime, date, timedelta
from pathlib import Path
from typing import Optional
from urllib.parse import quote

import requests

log = logging.getLogger("eol")

# ── Cache & persistence ───────────────────────────────────────────────────────
CACHE_DIR  = Path("eol_cache")
CACHE_DIR.mkdir(exist_ok=True)
CACHE_TTL  = 86400 * 3   # 3 days in seconds
_mem_cache = {}            # in-memory: product → {cycles, fetched_at}
_kev_cache = None          # CISA KEV catalog
_lock      = threading.Lock()

# ── endoflife.date product slug mapping ──────────────────────────────────────
# Maps detected name patterns → endoflife.date product slug
# Keys are lowercase substrings that may appear in banner/OS/sysDescr text
PRODUCT_MAP = {
    # Operating Systems
    "windows server 2008":  ("windows-server", "2008"),
    "windows server 2012":  ("windows-server", "2012"),
    "windows server 2016":  ("windows-server", "2016"),
    "windows server 2019":  ("windows-server", "2019"),
    "windows server 2022":  ("windows-server", "2022"),
    "windows 7":            ("windows", "7"),
    "windows 8.1":          ("windows", "8.1"),
    "windows 10":           ("windows", "10"),
    "windows 11":           ("windows", "11"),
    "ubuntu 14.04":         ("ubuntu", "14.04"),
    "ubuntu 16.04":         ("ubuntu", "16.04"),
    "ubuntu 18.04":         ("ubuntu", "18.04"),
    "ubuntu 20.04":         ("ubuntu", "20.04"),
    "ubuntu 22.04":         ("ubuntu", "22.04"),
    "ubuntu 24.04":         ("ubuntu", "24.04"),
    "debian 8":             ("debian", "8"),
    "debian 9":             ("debian", "9"),
    "debian 10":            ("debian", "10"),
    "debian 11":            ("debian", "11"),
    "debian 12":            ("debian", "12"),
    "centos 6":             ("centos", "6"),
    "centos 7":             ("centos", "7"),
    "centos 8":             ("centos", "8"),
    "rhel 6":               ("rhel", "6"),
    "rhel 7":               ("rhel", "7"),
    "rhel 8":               ("rhel", "8"),
    "rhel 9":               ("rhel", "9"),
    "red hat enterprise linux 7": ("rhel", "7"),
    "red hat enterprise linux 8": ("rhel", "8"),
    "red hat enterprise linux 9": ("rhel", "9"),
    "amazon linux 2":       ("amazon-linux", "2"),
    "amazon linux 2023":    ("amazon-linux", "2023"),
    "macos 10.15":          ("macos", "10.15"),
    "macos 11":             ("macos", "11"),
    "macos 12":             ("macos", "12"),
    "macos 13":             ("macos", "13"),
    "macos 14":             ("macos", "14"),

    # Network / Firewall OS
    "cisco ios 12":         ("cisco-ios", "12.4"),
    "cisco ios 15":         ("cisco-ios", "15.2"),
    "cisco ios xe 16":      ("cisco-ios-xe", "16"),
    "cisco ios xe 17":      ("cisco-ios-xe", "17"),
    "cisco nx-os":          ("cisco-nx-os", None),
    "junos":                ("junos", None),
    "fortigate":            ("fortios", None),
    "fortios":              ("fortios", None),
    "pan-os":               ("pan-os", None),
    "panos":                ("pan-os", None),

    # Web servers
    "apache/1.":            ("apache-http-server", "1"),
    "apache/2.2":           ("apache-http-server", "2.2"),
    "apache/2.4":           ("apache-http-server", "2.4"),
    "nginx/1.":             ("nginx", None),
    "nginx/0.":             ("nginx", None),
    "microsoft-iis/6":      ("iis", "6.0"),
    "microsoft-iis/7":      ("iis", "7.0"),
    "microsoft-iis/8":      ("iis", "8.5"),
    "microsoft-iis/10":     ("iis", "10.0"),

    # Databases
    "mysql 5.5":            ("mysql", "5.5"),
    "mysql 5.6":            ("mysql", "5.6"),
    "mysql 5.7":            ("mysql", "5.7"),
    "mysql 8.0":            ("mysql", "8.0"),
    "mysql 8.4":            ("mysql", "8.4"),
    "mariadb 10":           ("mariadb", "10"),
    "postgresql 9":         ("postgresql", "9"),
    "postgresql 10":        ("postgresql", "10"),
    "postgresql 11":        ("postgresql", "11"),
    "postgresql 12":        ("postgresql", "12"),
    "postgresql 13":        ("postgresql", "13"),
    "postgresql 14":        ("postgresql", "14"),
    "postgresql 15":        ("postgresql", "15"),
    "postgresql 16":        ("postgresql", "16"),
    "mongodb 4":            ("mongodb", "4"),
    "mongodb 5":            ("mongodb", "5"),
    "mongodb 6":            ("mongodb", "6"),
    "mongodb 7":            ("mongodb", "7"),
    "redis 6":              ("redis", "6"),
    "redis 7":              ("redis", "7"),
    "mssql 2012":           ("mssql", "2012"),
    "mssql 2014":           ("mssql", "2014"),
    "mssql 2016":           ("mssql", "2016"),
    "mssql 2017":           ("mssql", "2017"),
    "mssql 2019":           ("mssql", "2019"),
    "mssql 2022":           ("mssql", "2022"),

    # Runtimes & frameworks
    "python 2":             ("python", "2.7"),
    "python 3.6":           ("python", "3.6"),
    "python 3.7":           ("python", "3.7"),
    "python 3.8":           ("python", "3.8"),
    "python 3.9":           ("python", "3.9"),
    "python 3.10":          ("python", "3.10"),
    "python 3.11":          ("python", "3.11"),
    "python 3.12":          ("python", "3.12"),
    "node.js 14":           ("nodejs", "14"),
    "node.js 16":           ("nodejs", "16"),
    "node.js 18":           ("nodejs", "18"),
    "node.js 20":           ("nodejs", "20"),
    "node.js 22":           ("nodejs", "22"),
    "php 7":                ("php", "7"),
    "php 8.0":              ("php", "8.0"),
    "php 8.1":              ("php", "8.1"),
    "php 8.2":              ("php", "8.2"),
    "php 8.3":              ("php", "8.3"),
    "java 8":               ("java", "8"),
    "java 11":              ("java", "11"),
    "java 17":              ("java", "17"),
    "java 21":              ("java", "21"),
    "openssl 1.0":          ("openssl", "1.0"),
    "openssl 1.1":          ("openssl", "1.1"),
    "openssl 3.0":          ("openssl", "3.0"),
    "openssl 3.1":          ("openssl", "3.1"),
    "openssl 3.2":          ("openssl", "3.2"),
    "openssl 3.3":          ("openssl", "3.3"),

    # Virtualisation & Containers
    "vmware esxi 6":        ("vmware-esxi", "6"),
    "vmware esxi 7":        ("vmware-esxi", "7"),
    "vmware esxi 8":        ("vmware-esxi", "8"),
    "kubernetes 1.2":       ("kubernetes", "1.28"),
    "docker 2":             ("docker-engine", "20"),

    # IoT & embedded
    "openwrt 19":           ("openwrt", "19.07"),
    "openwrt 21":           ("openwrt", "21.02"),
    "openwrt 22":           ("openwrt", "22.03"),
    "openwrt 23":           ("openwrt", "23.05"),
    "dd-wrt":               ("dd-wrt", None),
}

# ── Version regex patterns for banner parsing ─────────────────────────────────
VERSION_PATTERNS = [
    # Apache: "Apache/2.4.41"
    (r"Apache/([\d.]+)", "apache-http-server"),
    # nginx: "nginx/1.18.0"
    (r"nginx/([\d.]+)", "nginx"),
    # OpenSSH + OS hint: "SSH-2.0-OpenSSH_8.2p1 Ubuntu-4ubuntu0.5"
    (r"OpenSSH_([\d.]+)", "openssh"),
    # IIS: "Microsoft-IIS/10.0"
    (r"Microsoft-IIS/([\d.]+)", "iis"),
    # MySQL: "5.7.39-MySQL Community Server"
    (r"([\d]+\.[\d]+\.[\d]+)-MySQL", "mysql"),
    # PostgreSQL: "PostgreSQL 14.5"
    (r"PostgreSQL ([\d]+\.[\d]+)", "postgresql"),
    # MongoDB: "MongoDB 6.0.3"
    (r"MongoDB ([\d]+\.[\d]+)", "mongodb"),
    # Redis: "Redis 7.0.5"
    (r"Redis ([\d]+\.[\d]+)", "redis"),
    # Python: "Python/3.9.7"
    (r"Python/([\d]+\.[\d]+)", "python"),
    # PHP: "PHP/8.1.12"
    (r"PHP/([\d]+\.[\d]+)", "php"),
    # Cisco IOS
    (r"Cisco IOS Software.+?Version ([\d.()A-Z]+)", "cisco-ios"),
    # Cisco IOS XE
    (r"Cisco IOS XE Software.+?Version ([\d.()A-Za-z]+)", "cisco-ios-xe"),
    # FortiOS
    (r"FortiOS ([\d.]+)", "fortios"),
    # PAN-OS
    (r"PAN-OS ([\d.]+)", "pan-os"),
    # Junos
    (r"JUNOS ([\d.A-Z]+)", "junos"),
    # VMware ESXi
    (r"VMware ESXi ([\d.]+)", "vmware-esxi"),
    # Windows version from OS detect
    (r"Windows Server 20(\d\d)", "windows-server"),
    (r"Windows (10|11)", "windows"),
    # Ubuntu
    (r"Ubuntu ([\d]+\.[\d]+)", "ubuntu"),
    # Debian
    (r"Debian GNU/Linux ([\d]+)", "debian"),
    # CentOS
    (r"CentOS Linux ([\d]+)", "centos"),
    # RHEL
    (r"Red Hat Enterprise Linux (?:Server|Workstation)? ?([\d]+)", "rhel"),
    # Node.js
    (r"node/([\d]+\.[\d]+)", "nodejs"),
    # OpenSSL
    (r"OpenSSL ([\d]+\.[\d]+)", "openssl"),
]

# ── EOL status constants ──────────────────────────────────────────────────────
STATUS_ACTIVE    = "active"          # fully supported
STATUS_LTS       = "lts"             # long-term support active
STATUS_SECURITY  = "security_only"   # only security patches
STATUS_EOL_SOON  = "eol_approaching" # EOL within 90 days
STATUS_EOL       = "eol"             # past EOL date
STATUS_EOS       = "eos"             # past end-of-support (no patches at all)
STATUS_UNKNOWN   = "unknown"         # no data found


class SoftwareVersion:
    """A software component detected on a device."""
    def __init__(self, product_slug, display_name, version, source):
        self.product_slug  = product_slug   # endoflife.date slug
        self.display_name  = display_name   # human name
        self.version       = version        # detected version string
        self.source        = source         # "banner", "snmp", "os_info", etc.

    def __repr__(self):
        return f"<SW {self.display_name} {self.version} via {self.source}>"


class EOLResult:
    """Lifecycle status for one software component on one device."""
    def __init__(self):
        self.product_slug   = ""
        self.display_name   = ""
        self.detected_ver   = ""
        self.cycle          = ""      # release cycle matched
        self.latest_ver     = ""      # latest in cycle
        self.release_date   = ""
        self.eol_date       = ""      # False=never, date string, True=already EOL
        self.support_date   = ""      # end of commercial support
        self.status         = STATUS_UNKNOWN
        self.days_until_eol = None    # negative = past EOL
        self.risk_score     = 0       # 0-100
        self.severity       = "info"  # info / medium / high / critical
        self.cve_count      = 0
        self.kev_count      = 0       # CISA known exploited
        self.source         = ""
        self.upgrade_to     = ""      # suggested upgrade path

    def to_dict(self):
        return {
            "product":      self.display_name,
            "product_slug": self.product_slug,
            "detected_ver": self.detected_ver,
            "cycle":        self.cycle,
            "latest_ver":   self.latest_ver,
            "eol_date":     str(self.eol_date),
            "support_date": str(self.support_date),
            "status":       self.status,
            "days_until_eol": self.days_until_eol,
            "risk_score":   self.risk_score,
            "severity":     self.severity,
            "cve_count":    self.cve_count,
            "kev_count":    self.kev_count,
            "upgrade_to":   self.upgrade_to,
            "source":       self.source,
        }


class EOLChecker:
    """
    Main EOL/EOS detection engine.
    Usage:
        checker = EOLChecker(config)
        results = checker.check_device(device_dict)
    """

    ENDOFLIFE_BASE  = "https://endoflife.date/api"
    NVD_BASE        = "https://services.nvd.nist.gov/rest/json/cves/2.0"
    CISA_KEV_URL    = "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json"
    OSV_BASE        = "https://api.osv.dev/v1"
    REQUEST_TIMEOUT = 12

    def __init__(self, config: dict = None):
        self.cfg      = config or {}
        self.nvd_key  = self.cfg.get("nvd_api_key", "")
        self._session = requests.Session()
        self._session.headers["User-Agent"] = "NetWatch-Pro/2.0"
        self._init_kev()

    # ── Public API ────────────────────────────────────────────────────────────
    def check_device(self, device: dict) -> list:
        """
        Given a device dict (from DB), return list of EOLResult objects,
        one per detected software component.
        """
        software = self._extract_software(device)
        results  = []
        for sw in software:
            r = self._check_one(sw)
            if r:
                results.append(r)
        return results

    def check_all_devices(self, devices: list) -> dict:
        """
        Batch check all devices. Returns {mac: [EOLResult, ...]}.
        Runs concurrently with thread pool.
        """
        import concurrent.futures
        out = {}
        with concurrent.futures.ThreadPoolExecutor(max_workers=8) as ex:
            futures = {ex.submit(self.check_device, d): d["mac"] for d in devices}
            for f in concurrent.futures.as_completed(futures):
                mac = futures[f]
                try:
                    out[mac] = [r.to_dict() for r in f.result()]
                except Exception as e:
                    log.warning(f"EOL check failed for {mac}: {e}")
        return out

    def get_product_list(self) -> list:
        """Fetch list of all products supported by endoflife.date."""
        return self._fetch_endoflife("all") or []

    # ── Software extraction ───────────────────────────────────────────────────
    def _extract_software(self, device: dict) -> list:
        """Pull software + version pairs from all available device signals."""
        found = {}  # slug+version → SoftwareVersion (dedup)

        def add(slug, name, version, source):
            key = f"{slug}:{version}"
            if key not in found and version:
                found[key] = SoftwareVersion(slug, name, version, source)

        # 1 — Parse version patterns from combined text signals
        signals = " | ".join(filter(None, [
            device.get("banner",""),
            device.get("os_info",""),
            (device.get("snmp_info") or {}).get("sysDescr",""),
            (device.get("snmp_info") or {}).get("sysName",""),
        ]))

        for pattern, slug in VERSION_PATTERNS:
            m = re.search(pattern, signals, re.IGNORECASE)
            if m:
                ver = m.group(1)
                name = slug.replace("-"," ").title()
                add(slug, name, ver, "banner/snmp")

        # 2 — OS info direct mapping
        os_lower = (device.get("os_info") or "").lower()
        for keyword, (slug, cycle) in PRODUCT_MAP.items():
            if keyword in os_lower or keyword in signals.lower():
                if cycle:
                    name = slug.replace("-"," ").title()
                    add(slug, name, cycle, "os_fingerprint")

        # 3 — SNMP sysDescr deep parse for network gear
        sysdescr = (device.get("snmp_info") or {}).get("sysDescr","")
        if sysdescr:
            # Cisco IOS version
            m = re.search(r"Version ([\d.()A-Z]+)", sysdescr)
            if m and "cisco" in sysdescr.lower():
                slug = "cisco-ios-xe" if "ios xe" in sysdescr.lower() else "cisco-ios"
                add(slug, slug.replace("-"," ").title(), m.group(1), "snmp")
            # FortiGate
            m = re.search(r"FortiGate.+?v([\d.]+)", sysdescr, re.I)
            if m:
                add("fortios","FortiOS", m.group(1), "snmp")

        # 4 — Open port hints (versions exposed on known ports)
        # Port 3306 MySQL, 5432 PostgreSQL, 6379 Redis, 27017 MongoDB
        # These would be populated by banner grabbing during active scan

        return list(found.values())

    # ── Single product check ──────────────────────────────────────────────────
    def _check_one(self, sw: SoftwareVersion) -> Optional[EOLResult]:
        """Query endoflife.date for one product+version. Returns EOLResult."""
        cycles = self._fetch_endoflife(sw.product_slug)
        if not cycles:
            return None

        # Find best matching cycle
        cycle_data = self._match_cycle(sw.version, cycles)
        if not cycle_data:
            return None

        r = EOLResult()
        r.product_slug  = sw.product_slug
        r.display_name  = sw.display_name
        r.detected_ver  = sw.version
        r.cycle         = str(cycle_data.get("cycle",""))
        r.latest_ver    = str(cycle_data.get("latest",""))
        r.release_date  = str(cycle_data.get("releaseDate",""))
        r.eol_date      = cycle_data.get("eol", False)
        r.support_date  = cycle_data.get("support", cycle_data.get("eol", ""))
        r.source        = sw.source

        # Calculate lifecycle status
        r.status, r.days_until_eol = self._calc_status(r.eol_date, r.support_date)

        # Enrich with CVE/KEV data
        r.cve_count, r.kev_count = self._get_vuln_counts(sw.product_slug, sw.version)

        # Risk score (0-100)
        r.risk_score = self._calc_risk(r.status, r.days_until_eol, r.cve_count, r.kev_count)
        r.severity   = self._risk_to_severity(r.risk_score)

        # Upgrade suggestion
        r.upgrade_to = self._latest_in_product(sw.product_slug, cycles)

        return r

    # ── endoflife.date API ────────────────────────────────────────────────────
    def _fetch_endoflife(self, product: str) -> Optional[list]:
        """Fetch product cycles from endoflife.date with local file cache."""
        global _mem_cache

        # Memory cache
        with _lock:
            if product in _mem_cache:
                entry = _mem_cache[product]
                if time.time() - entry["ts"] < CACHE_TTL:
                    return entry["data"]

        # File cache
        cache_file = CACHE_DIR / f"{product.replace('/','-')}.json"
        if cache_file.exists():
            age = time.time() - cache_file.stat().st_mtime
            if age < CACHE_TTL:
                try:
                    data = json.loads(cache_file.read_text())
                    with _lock:
                        _mem_cache[product] = {"data": data, "ts": time.time()}
                    return data
                except Exception:
                    pass

        # API fetch
        url = f"{self.ENDOFLIFE_BASE}/{quote(product)}.json"
        try:
            resp = self._session.get(url, timeout=self.REQUEST_TIMEOUT)
            if resp.status_code == 200:
                data = resp.json()
                cache_file.write_text(json.dumps(data))
                with _lock:
                    _mem_cache[product] = {"data": data, "ts": time.time()}
                return data
            elif resp.status_code == 404:
                log.debug(f"endoflife.date: no data for '{product}'")
        except Exception as e:
            log.warning(f"endoflife.date fetch error [{product}]: {e}")
        return None

    def _match_cycle(self, version: str, cycles: list) -> Optional[dict]:
        """Find the release cycle that best matches a detected version."""
        if not version or not cycles:
            return None
        # Normalise version to major.minor
        parts = re.split(r"[.\-()]", version)
        major = parts[0] if parts else ""
        minor = parts[1] if len(parts) > 1 else ""
        major_minor = f"{major}.{minor}" if minor else major

        # Exact cycle match first
        for c in cycles:
            cyc = str(c.get("cycle",""))
            if cyc == version or cyc == major_minor:
                return c
        # Prefix match (e.g. version "15.2(4)M" → cycle "15.2")
        for c in cycles:
            cyc = str(c.get("cycle",""))
            if version.startswith(cyc) or major_minor.startswith(cyc):
                return c
        # Major-only match
        for c in cycles:
            cyc = str(c.get("cycle","")).split(".")[0]
            if major == cyc:
                return c
        return None

    def _calc_status(self, eol_date, support_date) -> tuple:
        """Return (status_string, days_until_eol_int_or_None)."""
        today = date.today()

        def parse_date(d):
            if not d or d is True or d is False:
                return None
            try:
                return date.fromisoformat(str(d))
            except Exception:
                return None

        eol_dt  = parse_date(eol_date)
        sup_dt  = parse_date(support_date)

        # EOL = False means "never EOL" (rolling release)
        if eol_date is False:
            return STATUS_ACTIVE, None

        # Past EOS (no support at all)
        if sup_dt and today > sup_dt and eol_dt and today > eol_dt:
            days = (today - eol_dt).days
            return STATUS_EOS, -days

        # Past EOL date
        if eol_dt and today > eol_dt:
            days = (today - eol_dt).days
            return STATUS_EOL, -days

        # Approaching EOL (within 90 days)
        if eol_dt:
            days = (eol_dt - today).days
            if days <= 90:
                return STATUS_EOL_SOON, days
            return STATUS_ACTIVE, days

        # Only support date available
        if sup_dt:
            if today > sup_dt:
                return STATUS_SECURITY, -(today - sup_dt).days
            days = (sup_dt - today).days
            if days <= 90:
                return STATUS_EOL_SOON, days
            return STATUS_LTS, days

        return STATUS_UNKNOWN, None

    def _latest_in_product(self, slug: str, cycles: list) -> str:
        """Return the latest cycle version for upgrade suggestion."""
        if not cycles:
            return ""
        # Prefer non-EOL cycles with most recent releaseDate
        active = [c for c in cycles if c.get("eol") is False or
                  (isinstance(c.get("eol"), str) and
                   date.fromisoformat(c["eol"]) > date.today())]
        pool = active if active else cycles
        try:
            pool.sort(key=lambda c: c.get("releaseDate",""), reverse=True)
            return str(pool[0].get("latest", pool[0].get("cycle","")))
        except Exception:
            return ""

    # ── CVE / KEV enrichment ──────────────────────────────────────────────────
    def _init_kev(self):
        """Load CISA KEV catalog into memory (fetched once per session)."""
        global _kev_cache
        if _kev_cache is not None:
            return
        kev_file = CACHE_DIR / "cisa_kev.json"
        if kev_file.exists() and time.time() - kev_file.stat().st_mtime < CACHE_TTL:
            try:
                _kev_cache = json.loads(kev_file.read_text()).get("vulnerabilities", [])
                log.info(f"CISA KEV loaded from cache: {len(_kev_cache)} entries")
                return
            except Exception:
                pass
        try:
            resp = self._session.get(self.CISA_KEV_URL, timeout=30)
            if resp.status_code == 200:
                data = resp.json()
                kev_file.write_text(json.dumps(data))
                _kev_cache = data.get("vulnerabilities", [])
                log.info(f"CISA KEV fetched: {len(_kev_cache)} entries")
                return
        except Exception as e:
            log.warning(f"CISA KEV fetch error: {e}")
        _kev_cache = []

    def _get_vuln_counts(self, slug: str, version: str) -> tuple:
        """Return (total_cve_count, kev_count) for a product version."""
        kev_count = self._kev_count(slug, version)
        cve_count = self._nvd_count(slug, version)
        return cve_count, kev_count

    def _kev_count(self, slug: str, version: str) -> int:
        """Count CISA KEV entries matching this product."""
        if not _kev_cache:
            return 0
        slug_words = set(slug.lower().replace("-"," ").split())
        count = 0
        for entry in _kev_cache:
            product_str = (entry.get("product","") + " " + entry.get("vendorProject","")).lower()
            if any(w in product_str for w in slug_words if len(w) > 3):
                count += 1
        return count

    def _nvd_count(self, slug: str, version: str) -> int:
        """Query NVD CVE API for vulnerability count (rate limited — use sparingly)."""
        if not self.cfg.get("nvd_enabled", False):
            return 0
        try:
            # Map slug to CPE prefix
            cpe_map = {
                "apache-http-server": "cpe:2.3:a:apache:http_server",
                "nginx":              "cpe:2.3:a:nginx:nginx",
                "mysql":              "cpe:2.3:a:mysql:mysql",
                "postgresql":         "cpe:2.3:a:postgresql:postgresql",
                "openssl":            "cpe:2.3:a:openssl:openssl",
            }
            cpe = cpe_map.get(slug)
            if not cpe:
                return 0
            params = {"cpeName": f"{cpe}:{version}:*:*:*:*:*:*:*:*", "resultsPerPage": 1}
            headers = {}
            if self.nvd_key:
                headers["apiKey"] = self.nvd_key
            resp = self._session.get(self.NVD_BASE, params=params,
                                     headers=headers, timeout=self.REQUEST_TIMEOUT)
            if resp.status_code == 200:
                return resp.json().get("totalResults", 0)
        except Exception as e:
            log.debug(f"NVD query error: {e}")
        return 0

    # ── Risk scoring ──────────────────────────────────────────────────────────
    def _calc_risk(self, status: str, days: Optional[int], cves: int, kevs: int) -> int:
        """Calculate 0-100 risk score."""
        score = 0
        # Lifecycle status contribution (0-60)
        score += {
            STATUS_EOS:       60,
            STATUS_EOL:       50,
            STATUS_EOL_SOON:  35,
            STATUS_SECURITY:  20,
            STATUS_LTS:       5,
            STATUS_ACTIVE:    0,
            STATUS_UNKNOWN:   10,
        }.get(status, 0)

        # Days past EOL contribution (up to +15)
        if days is not None and days < 0:
            overage = min(abs(days), 365 * 3)
            score += min(15, int(overage / 365 * 15))

        # CVE contribution (up to +15)
        score += min(15, cves // 5)

        # KEV contribution (up to +10 — highest urgency signal)
        score += min(10, kevs * 3)

        return min(100, score)

    def _risk_to_severity(self, score: int) -> str:
        if score >= 75: return "critical"
        if score >= 50: return "high"
        if score >= 25: return "medium"
        return "info"

    # ── Convenience ───────────────────────────────────────────────────────────
    def eol_summary(self, device: dict) -> dict:
        """Quick summary dict for API response."""
        results = self.check_device(device)
        if not results:
            return {"status": "no_software_detected", "items": [], "worst_severity": "info"}
        worst = max(results, key=lambda r: r.risk_score)
        return {
            "status":         worst.status,
            "worst_severity": worst.severity,
            "worst_score":    worst.risk_score,
            "items":          [r.to_dict() for r in sorted(results, key=lambda x: -x.risk_score)],
            "total":          len(results),
            "eol_count":      sum(1 for r in results if r.status in (STATUS_EOL, STATUS_EOS)),
            "critical_count": sum(1 for r in results if r.severity == "critical"),
        }


# ── Flask API routes (add to app.py) ─────────────────────────────────────────
def register_eol_routes(app, checker: EOLChecker, db_module):
    """
    Call this in app.py:
        from eol_checker import EOLChecker, register_eol_routes
        eol = EOLChecker(config)
        register_eol_routes(app, eol, db)
    """
    from flask import jsonify, request as freq

    @app.route("/api/eol/device/<mac>")
    def api_eol_device(mac):
        device = db_module.get_device(mac)
        if not device:
            return jsonify({"error":"not found"}), 404
        return jsonify(checker.eol_summary(device))

    @app.route("/api/eol/scan", methods=["POST"])
    def api_eol_scan():
        """Trigger EOL check across all devices."""
        devices = db_module.get_all_devices()
        results = checker.check_all_devices(devices)
        # Persist results to DB eol_data column
        for mac, items in results.items():
            with db_module.get_conn() as conn:
                conn.execute(
                    "UPDATE devices SET eol_data=?, eol_worst_severity=? WHERE mac=?",
                    (json.dumps(items),
                     max((i.get("severity","info") for i in items),
                         key=lambda s: {"info":0,"medium":1,"high":2,"critical":3}.get(s,0),
                         default="info"),
                     mac)
                )
        eol_count    = sum(1 for items in results.values()
                           for i in items if i.get("status") in ("eol","eos"))
        crit_devices = sum(1 for items in results.values()
                           if any(i.get("severity")=="critical" for i in items))
        return jsonify({
            "ok":True, "devices_checked":len(results),
            "eol_findings":eol_count, "critical_devices":crit_devices
        })

    @app.route("/api/eol/dashboard")
    def api_eol_dashboard():
        """Aggregated EOL stats for the dashboard EOL tab."""
        from collections import Counter
        devices = db_module.get_all_devices()
        all_items = []
        for d in devices:
            eol_raw = d.get("eol_data")
            if eol_raw:
                try:
                    items = json.loads(eol_raw) if isinstance(eol_raw,str) else eol_raw
                    for item in items:
                        item["device_ip"]  = d.get("ip","")
                        item["device_mac"] = d.get("mac","")
                        item["device_label"]= d.get("label","") or d.get("hostname","")
                        all_items.append(item)
                except Exception:
                    pass
        status_counts  = Counter(i.get("status","unknown") for i in all_items)
        severity_counts = Counter(i.get("severity","info") for i in all_items)
        top_risks = sorted(all_items, key=lambda x: -x.get("risk_score",0))[:20]
        return jsonify({
            "total_software": len(all_items),
            "status_counts":  dict(status_counts),
            "severity_counts":dict(severity_counts),
            "top_risks":      top_risks,
            "eol_products":   [i for i in all_items if i.get("status") in ("eol","eos")],
        })


# ── DB schema additions (call from db.init_db) ────────────────────────────────
EOL_SCHEMA_SQL = """
ALTER TABLE devices ADD COLUMN eol_data TEXT DEFAULT '[]';
ALTER TABLE devices ADD COLUMN eol_worst_severity TEXT DEFAULT 'info';
ALTER TABLE devices ADD COLUMN eol_last_checked TEXT;

CREATE TABLE IF NOT EXISTS eol_products (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    mac          TEXT,
    product_slug TEXT,
    display_name TEXT,
    detected_ver TEXT,
    cycle        TEXT,
    latest_ver   TEXT,
    eol_date     TEXT,
    support_date TEXT,
    status       TEXT,
    days_until_eol INTEGER,
    risk_score   INTEGER,
    severity     TEXT,
    cve_count    INTEGER DEFAULT 0,
    kev_count    INTEGER DEFAULT 0,
    upgrade_to   TEXT,
    source       TEXT,
    checked_at   TEXT,
    FOREIGN KEY (mac) REFERENCES devices(mac) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_eol_mac      ON eol_products(mac);
CREATE INDEX IF NOT EXISTS idx_eol_severity ON eol_products(severity);
CREATE INDEX IF NOT EXISTS idx_eol_status   ON eol_products(status);
"""


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    checker = EOLChecker()

    # Quick self-test
    test_device = {
        "mac":     "aa:bb:cc:dd:ee:ff",
        "ip":      "192.168.1.10",
        "banner":  "Apache/2.4.51 (Ubuntu) OpenSSL/1.1.1f PHP/7.4.3",
        "os_info": "Ubuntu 18.04",
        "snmp_info": {},
    }
    results = checker.check_device(test_device)
    for r in results:
        print(f"\n{'='*55}")
        print(f"  {r.display_name} {r.detected_ver}")
        print(f"  Status   : {r.status}")
        print(f"  EOL date : {r.eol_date}")
        print(f"  Days     : {r.days_until_eol}")
        print(f"  Risk     : {r.risk_score}/100  [{r.severity.upper()}]")
        print(f"  Upgrade  : {r.upgrade_to}")
        print(f"  CVEs     : {r.cve_count}  KEV: {r.kev_count}")
